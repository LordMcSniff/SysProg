#include "../lib/MLF.h"
#include <stdio.h>
static queue_object **MLF_queues;
//You can add more global variables here

process *MLF_tick(process *running_process)
{
	// TODO
	return NULL;
}

int MLF_startup()
{
	// TODO
	return 1;
}



process *MLF_new_arrival(process *arriving_process, process *running_process)
{
	// TODO
	return NULL;
}

void MLF_finish()
{
	// TODO
}
