#include "../lib/queue.h"
#include <stdlib.h>
#include <stdio.h>

int queue_add(void *new_object, queue_object *queue)
{
	// TODO
	return 1;
}

void *queue_poll(queue_object *queue)
{
	// TODO
	return NULL;
}

queue_object *new_queue()
{
	// TODO
	return NULL;
}

void free_queue(queue_object *queue)
{
	// TODO
}

void *queue_peek(queue_object *queue)
{
	// TODO
	return NULL;
}
