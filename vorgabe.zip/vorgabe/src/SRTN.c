#include "../lib/SRTN.h"

static queue_object *SRTN_queue;
//You can add more global variables here

process *SRTN_tick(process *running_process)
{
	// TODO
	return NULL;
}

int SRTN_startup()
{
	// TODO
	return 1;
}

process *SRTN_new_arrival(process *arriving_process, process *running_process)
{
	// TODO
	return NULL;
}

void SRTN_finish()
{
	// TODO
}
