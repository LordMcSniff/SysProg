#include "../lib/HRRN.h"

static queue_object *HRRN_queue;
//You can add more global variables and structs here

process *HRRN_tick(process *running_process)
{
	// TODO
	return NULL;
}

int HRRN_startup()
{
	// TODO
	return 1;
}

process *HRRN_new_arrival(process *arriving_process, process *running_process)
{
	// TODO
	return NULL;
}

void HRRN_finish()
{
	// TODO
}
