#include "../lib/RR.h"

static queue_object *RR_queue;
//You can add more global variables

process *RR_tick(process *running_process)
{
	// TODO
	return NULL;
}

int RR_startup(int quantum)
{
	// TODO
	return 1;
}

process *RR_new_arrival(process *arriving_process, process *running_process)
{
	// TODO
	return NULL;
}

void RR_finish()
{
	// TODO
}
