#include "../lib/PRIOP.h"
#include <stdio.h>

static queue_object *PRIOP_queue;
//You can add more global variables here

process *PRIOP_tick(process *running_process)
{
	// TODO
	return NULL;
}

int PRIOP_startup()
{
	// TODO
	return 1;
}

process *PRIOP_new_arrival(process *arriving_process, process *running_process)
{
	// TODO
	return NULL;
}

void PRIOP_finish()
{
	// TODO
}
