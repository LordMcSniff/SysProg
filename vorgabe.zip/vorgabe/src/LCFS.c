#include "../lib/LCFS.h"

static queue_object *LCFS_queue;
//You can add more global variables here

int LCFS_startup()
{
	// TODO
	return 0;
}

process *LCFS_tick(process *running_process)
{
	// TODO
	return NULL;
}

process *LCFS_new_arrival(process *arriving_process, process *running_process)
{
	// TODO
	return NULL;
}

void LCFS_finish()
{
	// TODO
}
